#!/bin/bash
WORKSPACE="$1"

if [ -z "$WORKSPACE" ]; then
  echo "No workspace specified. Usage: ./manage_workspace.sh <workspace-name>"
  exit 1
fi

terraform workspace select "$WORKSPACE"
terraform destroy -var-file="$WORKSPACE.tfvars"
