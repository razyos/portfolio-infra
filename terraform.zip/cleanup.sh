#!/bin/bash

# Get all namespaces
namespaces=$(kubectl get namespaces -o jsonpath="{.items[*].metadata.name}")

# Iterate over each namespace
for namespace in $namespaces; do
    echo "Deleting all Kubernetes resources in the namespace: $namespace..."
    kubectl delete all --all -n $namespace

    echo "Deleting all Persistent Volume Claims in the namespace: $namespace..."
    kubectl delete pvc --all -n $namespace
done

echo "Deleting all Persistent Volumes..."
kubectl delete pv --all

# Uninstall AWS EBS CSI Driver if it was installed via Helm
echo "Uninstalling AWS EBS CSI Driver..."
helm uninstall aws-ebs-csi-driver -n kube-system

# Alternatively, if the CSI Driver was installed directly via kubectl
# echo "Deleting AWS EBS CSI Driver installed via kubectl..."
# kubectl delete -k "github.com/kubernetes-sigs/aws-ebs-csi-driver/deploy/kubernetes/overlays/stable/ecr/?ref=release-1.16"

# Clean up orphaned EBS volumes
echo "Cleaning up orphaned EBS volumes..."
orphaned_volumes=$(aws ec2 describe-volumes --filters Name=status,Values=available --query "Volumes[*].VolumeId" --output text)

if [ -z "$orphaned_volumes" ]; then
    echo "No orphaned EBS volumes found."
else
    for volume_id in $orphaned_volumes; do
        echo "Deleting EBS volume: $volume_id"
        aws ec2 delete-volume --volume-id $volume_id
    done
fi

# Destroy the EKS cluster using Terraform
echo "Destroying the EKS cluster using Terraform..."
terraform destroy -auto-approve

# Final verification for orphaned resources
echo "Final verification for any remaining resources..."

# Check for any remaining orphaned volumes
orphaned_volumes=$(aws ec2 describe-volumes --filters Name=status,Values=available --query "Volumes[*].VolumeId" --output text)

if [ -z "$orphaned_volumes" ]; then
    echo "No remaining orphaned EBS volumes found."
else
    echo "Orphaned EBS volumes found, please delete them manually:"
    echo "$orphaned_volumes"
fi

# Check for any remaining load balancers
remaining_lbs=$(aws elb describe-load-balancers --query "LoadBalancerDescriptions[*].LoadBalancerName" --output text)
if [ -z "$remaining_lbs" ]; then
    echo "No remaining Load Balancers found."
else
    echo "Remaining Load Balancers found, please delete them manually:"
    echo "$remaining_lbs"
fi

echo "Cleanup complete."
