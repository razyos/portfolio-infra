terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.59.0"
    }
  }
  // Run terraform init -backend-config=backend-config.hcl
  backend "s3" {}
}

provider "aws" {
  region = var.aws_region
}