aws_region          = "us-east-1"
vpc_cidr            = "10.0.0.0/24"
number_of_subnets   = 2
instance_type       = "t3a.medium"
key_name            = "raz.yosef-key"

base_tags = {
    owner           = "raz.yosef"
    bootcamp        = "BC21"
    expiration_date = "18-09-24"    
}

env = "prod"

# EKS Cluster Variables
cluster_name            = "razyosefkubernetesEKS"
kubernetes_version      = "1.27"
endpoint_private_access = false
endpoint_public_access  = true

# EKS Node Group Variables
node_group_name = "razyosefkubernetesNG"
desired_size    = 2
max_size        = 3
min_size        = 1

# EKS Add-ons Variables
enable_vpc_cni_addon     = true
enable_coredns_addon     = true
enable_kube_proxy_addon  = true
vpc_cni_addon_version    = "v1.12.6-eksbuild.1"  # null for latest
coredns_addon_version    = "v1.9.3-eksbuild.3"   # null for latest
kube_proxy_addon_version = "v1.27.1-eksbuild.1"  # null for latest

# Cluster Autoscaler Add-on Variables
enable_cluster_autoscaler_addon = true
cluster_autoscaler_addon_version = "v1.27.2"  # Adjust as needed

# EBS CSI Driver Add-on Variables
enable_ebs_csi_driver_addon = true
ebs_csi_driver_addon_version = "v1.16.0"  # Adjust as needed
